#
# TABLE STRUCTURE FOR: accounts
#

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `accounts` (`id`, `username`, `password`, `type`) VALUES (1, 'admin', 'admin', 'admin');
INSERT INTO `accounts` (`id`, `username`, `password`, `type`) VALUES (3, 'admin23', 'admin', 'user');
INSERT INTO `accounts` (`id`, `username`, `password`, `type`) VALUES (4, 'admin', 'admin', 'user');


#
# TABLE STRUCTURE FOR: allowed
#

DROP TABLE IF EXISTS `allowed`;

CREATE TABLE `allowed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `head` longtext,
  `title` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `allowed` (`id`, `head`, `title`) VALUES (1, '[\"name\",\"date\",\"status\",\"location_address\"]', '[\"Name\",\"Date\",\"Status\",\"Full Address\"]');


#
# TABLE STRUCTURE FOR: barangay
#

DROP TABLE IF EXISTS `barangay`;

CREATE TABLE `barangay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `barangay` (`id`, `name`) VALUES (1, 'Bonfal East');
INSERT INTO `barangay` (`id`, `name`) VALUES (2, 'Bonfal Proper');
INSERT INTO `barangay` (`id`, `name`) VALUES (3, 'Bonfal West');
INSERT INTO `barangay` (`id`, `name`) VALUES (4, 'Buenavista');
INSERT INTO `barangay` (`id`, `name`) VALUES (5, 'Busilac');
INSERT INTO `barangay` (`id`, `name`) VALUES (6, 'Casat');
INSERT INTO `barangay` (`id`, `name`) VALUES (20, 'La Torre North');
INSERT INTO `barangay` (`id`, `name`) VALUES (7, 'Magapuy');
INSERT INTO `barangay` (`id`, `name`) VALUES (8, 'Magsaysay');
INSERT INTO `barangay` (`id`, `name`) VALUES (9, 'Masoc');
INSERT INTO `barangay` (`id`, `name`) VALUES (10, 'Paitan');
INSERT INTO `barangay` (`id`, `name`) VALUES (11, 'Don Domingo Maddela');
INSERT INTO `barangay` (`id`, `name`) VALUES (12, 'Don Tomas Maddela');
INSERT INTO `barangay` (`id`, `name`) VALUES (13, 'District III');
INSERT INTO `barangay` (`id`, `name`) VALUES (14, 'District IV');
INSERT INTO `barangay` (`id`, `name`) VALUES (15, 'Bansing');
INSERT INTO `barangay` (`id`, `name`) VALUES (16, 'Cabuaan');
INSERT INTO `barangay` (`id`, `name`) VALUES (17, 'Don Mariano Marcos');
INSERT INTO `barangay` (`id`, `name`) VALUES (18, 'Ipil-Cuneg');
INSERT INTO `barangay` (`id`, `name`) VALUES (19, 'La Torre South');
INSERT INTO `barangay` (`id`, `name`) VALUES (21, 'Luyang');
INSERT INTO `barangay` (`id`, `name`) VALUES (22, 'Salvacion');
INSERT INTO `barangay` (`id`, `name`) VALUES (23, 'San Nicholas');
INSERT INTO `barangay` (`id`, `name`) VALUES (24, 'Santa Rosa');
INSERT INTO `barangay` (`id`, `name`) VALUES (25, 'Vista Alegre');


#
# TABLE STRUCTURE FOR: business
#

DROP TABLE IF EXISTS `business`;

CREATE TABLE `business` (
  `number` int(11) NOT NULL AUTO_INCREMENT,
  `bin` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `owner` varchar(100) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `address` int(11) DEFAULT NULL,
  `incentives` tinyint(1) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `category` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `barangay_clearance` tinyint(1) DEFAULT '0',
  `tax_clearance` tinyint(1) DEFAULT '0',
  `dti_registration` tinyint(1) DEFAULT '0',
  `sanitary_clearance` tinyint(1) DEFAULT '0',
  `fire_clearance` tinyint(1) DEFAULT '0',
  `building_permit` tinyint(1) DEFAULT '0',
  `zoning_clearance` tinyint(1) DEFAULT '0',
  `contract_lease` tinyint(1) DEFAULT '0',
  `pic_clearance` tinyint(1) DEFAULT '0',
  `menro_cert` tinyint(1) DEFAULT '0',
  `building_id` int(11) DEFAULT NULL,
  `business_area` double DEFAULT NULL,
  `accomplished` date DEFAULT NULL,
  `remarks` longtext,
  PRIMARY KEY (`number`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (7, '142-1', 'BREAD N BITES', 'Asuncion, Sean Valdez', 36, 7, NULL, 'Single', 'Pending', 'Wholesaler', '2023-10-10', 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 142, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (8, '136-2', 'JMA BOARDING HOUSE & SARI-SARI STORE', 'Marcos, June Bugnoy', 37, 8, NULL, 'Single', 'Pending', 'Manufacturer', '2023-10-05', 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 136, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (6, '134-2', 'KKOPI', 'Morales, Paul ', 35, 6, NULL, 'Single', 'Registered', 'Lessor Financial', '2023-10-20', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 134, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (10, '139-3', 'Tara Laba', 'Gread, Tim Burne', 38, 10, NULL, 'Single', 'Pending', 'Real Estate', '2023-10-20', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 139, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (55, '136-4', 'MZ Laundry Shop', 'Minerva, Zeta Tan', 39, 9, NULL, 'Cooperative', 'Removed', 'Services', '2023-10-20', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 136, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (56, '139-2', 'Someone Business', 'Geyben, Ong ', 40, 12, NULL, 'Partnership', 'Pending', 'Lessor Financial', '2023-10-20', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 139, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (57, '148-57', 'MicroTrendTestProject', 'Garces, Sherwyn Miranda', 41, 20, NULL, 'Single', 'Pending', 'Manufacturer', '2023-10-22', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 148, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (58, '149-58', 'UniteLibrary', 'Last, First Middle', 42, 21, NULL, 'Single', 'Pending', 'Manufacturer', '2023-10-22', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 149, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (59, '150-59', 'RC', 'lejao, kyle g', 43, 22, NULL, 'Single', 'Pending', 'Retailer', '2023-10-23', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 150, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (60, '152-60', 'Computernisumawang', 'rodrigo, james amorin', 44, 23, NULL, 'Single', 'Registered', 'Manufacturer', '2023-10-23', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 152, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (62, '154-62', 'Felisas', 'Amorin , Rodrigo Jr S.', 46, 25, NULL, 'Single', 'Registered', 'Services', '2023-10-26', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 154, NULL, NULL, NULL);
INSERT INTO `business` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `accomplished`, `remarks`) VALUES (63, '134-63', 'Drinker', 'Amorin, Rdgie Suma', 47, 6, NULL, 'Single', 'Pending', 'Manufacturer', '2023-10-26', 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 134, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: business_address
#

DROP TABLE IF EXISTS `business_address`;

CREATE TABLE `business_address` (
  `building_id` int(11) NOT NULL AUTO_INCREMENT,
  `pin` int(11) DEFAULT NULL,
  `bldg_no` int(11) DEFAULT NULL,
  `building_name` varchar(60) DEFAULT NULL,
  `unit_no` int(11) DEFAULT NULL,
  `street` varchar(60) DEFAULT NULL,
  `barangay` varchar(60) DEFAULT NULL,
  `subdivision` varchar(60) DEFAULT NULL,
  `city` varchar(60) DEFAULT NULL,
  `province` varchar(60) DEFAULT NULL,
  `tel_no` bigint(20) DEFAULT NULL,
  `email_address` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`building_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (6, 134, 0, 'Commercial Bldg', 133, 'Ponce Street', 'Don Mariano Marcos', '', 'Bayombong', 'Nueva Vizcaya', '0', 'kkopi@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (7, 135, 2331, 'Breads N Bites', 0, 'Burgos Street', 'Don Mariano Perez', '', 'Bayombong', 'Nueva Vizcaya', '0', 'Marie98@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (8, 136, 4335, 'JMA Building', 23, 'Cabarroguis', 'Salvacion', '', 'Bayombong', 'Nueva Vizcaya', '9356631100', 'almajan@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (9, 137, 0, 'RS AND JOY Building', 0, 'Regidor Street', 'Don Mariano Marcos', '', 'Bayombong', 'Nueva Vizcaya', '9116801221', 'MaryJane@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (10, 138, 553, 'None', 0, 'Dumlao Boulevard', 'Salvacion', 'Boulevard', 'Bayombong', 'Nueva Vizcaya', '0', 'Lozano6114@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (11, 139, 0, 'TaraLaba Bldg', 0, 'Mabini Street', 'Salvacion', 'Purok 5', 'Bayombong', 'Nueva Vizcaya', '6778', 'agassid@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (12, 140, 2, 'LADESMA Building House', 348, 'Regidor Street', 'Don Mariano Marcos', 'Purok 3', 'Bayombong', 'Nueva Vizcaya', '87792231', 'Ong2@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (13, 141, 0, 'BGM Building', 324, 'Dumlao Boulevard', 'Salvacion', 'purok 1', 'Bayombong', 'Nueva Vizcaya', '0', 'Delos_Santos@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (14, 142, 354, 'Not building', 698, 'Sanjose Street', 'National', 'purok 2', 'Bayombong', 'Nueva Vizcaya', '44313453', 'barutan@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (15, 143, 327, 'Commercial Store', 13, 'Zamora Street', 'Don Domingo Maddela', 'Purok 6', 'Bayombong', 'Nueva Vizcaya', '933421242', 'PawfeeQ@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (16, 144, 782, 'TaraLaba Building', 28, 'Mabini Street', 'Salvacion', 'Purok 5', 'Bayombong', 'Nueva Vizcaya', '2433212', 'kaylagads@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (17, 145, 0, 'Commercial Store', 872, 'Dumlao Boulevard', 'Don perez', 'purok 3', 'Bayombong', 'Nueva Vizcaya', '0', 'jouhue@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (18, 146, 0, 'Commercial Store', 438, 'Dumlao Boulevard', 'Don Mariano Perez', 'purok 1', 'Bayombong', 'Nueva Vizcaya', '0', 'jouhe@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (19, 147, 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (20, 148, 0, '', 36, 'Cabarroguis', 'Salvacion', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (21, 149, 0, '', 23, 'Zulueta', 'Salvacion', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (22, 150, 0, '', 23, 'Saranay', 'Batal', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (23, 152, 0, 'lejao Bldg', 112, 'Borgos street', 'Salvacion', '', 'Bayombong', 'Nueva Vizcaya', '23324', 'giegie@gmail.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (24, 153, 343, 'test', 0, 'Boulevard', 'Salvacion', '', 'Bayombong', 'Nueva Vizcaya', '343', 'sherlyn.garces@yahoo.com');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (25, 154, 0, 'Felisas Coffe Shop', 0, '', 'District IV', '', 'Bayombong', 'Nueva Vizcaya', '98', '');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (26, 155, 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (27, 255, 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_address` (`building_id`, `pin`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (28, 256, 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');


#
# TABLE STRUCTURE FOR: business_logs
#

DROP TABLE IF EXISTS `business_logs`;

CREATE TABLE `business_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `bid` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=614 DEFAULT CHARSET=latin1;

INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (61, '2023-10-20 11:49:01', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (62, '2023-10-20 11:50:34', 48, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (63, '2023-10-20 11:50:34', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (64, '2023-10-20 11:50:46', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (65, '2023-10-20 11:51:43', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (66, '2023-10-20 11:52:10', 48, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (67, '2023-10-20 11:52:10', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (68, '2023-10-20 11:52:33', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (69, '2023-10-20 11:57:44', 48, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (70, '2023-10-20 11:57:44', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (71, '2023-10-20 11:58:34', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (72, '2023-10-20 11:59:00', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (73, '2023-10-20 11:59:05', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (74, '2023-10-20 12:05:47', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (75, '2023-10-20 12:05:50', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (76, '2023-10-20 12:05:51', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (77, '2023-10-20 12:05:51', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (78, '2023-10-20 12:05:52', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (79, '2023-10-20 12:05:52', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (80, '2023-10-20 12:05:52', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (81, '2023-10-20 12:05:53', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (82, '2023-10-20 12:05:53', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (83, '2023-10-20 12:05:53', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (84, '2023-10-20 12:09:10', 48, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (85, '2023-10-20 12:09:10', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (86, '2023-10-20 12:11:19', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (87, '2023-10-20 12:13:20', 48, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (88, '2023-10-20 12:13:20', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (89, '2023-10-20 12:15:51', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (90, '2023-10-20 12:18:19', 48, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (91, '2023-10-20 12:18:19', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (92, '2023-10-20 12:18:31', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (93, '2023-10-20 12:23:28', 48, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (94, '2023-10-20 12:23:28', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (95, '2023-10-20 13:16:19', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (96, '2023-10-20 13:18:31', 48, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (97, '2023-10-20 13:18:31', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (98, '2023-10-20 13:18:39', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (99, '2023-10-20 13:20:26', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (100, '2023-10-20 13:21:27', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (101, '2023-10-20 13:21:37', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (102, '2023-10-20 13:21:42', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (103, '2023-10-20 13:22:09', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (104, '2023-10-20 15:04:24', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (105, '2023-10-20 15:04:43', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (106, '2023-10-20 15:06:24', 48, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (107, '2023-10-21 00:17:07', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (108, '2023-10-21 00:23:10', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (109, '2023-10-21 00:28:01', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (110, '2023-10-21 00:32:35', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (111, '2023-10-21 00:37:21', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (112, '2023-10-21 00:42:51', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (113, '2023-10-21 00:48:40', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (114, '2023-10-21 00:52:33', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (115, '2023-10-21 00:58:30', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (116, '2023-10-21 01:05:07', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (117, '2023-10-21 01:09:32', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (118, '2023-10-21 01:14:27', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (119, '2023-10-21 01:17:30', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (120, '2023-10-21 01:21:15', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (121, '2023-10-21 01:21:15', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (122, '2023-10-21 01:21:15', 49, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (123, '2023-10-21 01:21:48', 49, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (124, '2023-10-21 01:21:48', 49, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (125, '2023-10-21 01:23:43', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (126, '2023-10-21 01:23:43', 50, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (127, '2023-10-21 01:25:34', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (128, '2023-10-21 01:25:34', 51, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (129, '2023-10-21 01:26:42', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (130, '2023-10-21 01:26:42', 52, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (131, '2023-10-21 01:27:50', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (132, '2023-10-21 01:27:50', 53, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (133, '2023-10-21 01:28:45', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (134, '2023-10-21 01:28:45', 54, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (135, '2023-10-21 01:29:55', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (136, '2023-10-21 01:29:55', 55, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (137, '2023-10-21 01:31:16', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (138, '2023-10-21 01:31:16', 56, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (139, '2023-10-21 21:42:12', 53, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (140, '2023-10-21 21:42:12', 53, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (141, '2023-10-21 21:42:14', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (142, '2023-10-21 21:42:14', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (143, '2023-10-21 21:42:35', 56, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (144, '2023-10-21 21:43:45', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (145, '2023-10-21 21:43:51', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (146, '2023-10-21 21:43:55', 53, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (147, '2023-10-21 21:43:59', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (148, '2023-10-21 21:44:03', 54, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (149, '2023-10-21 21:44:09', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (150, '2023-10-21 21:44:13', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (151, '2023-10-21 21:44:17', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (152, '2023-10-21 21:44:21', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (153, '2023-10-21 21:44:29', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (154, '2023-10-21 21:49:21', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (155, '2023-10-21 21:49:21', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (156, '2023-10-21 21:52:38', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (157, '2023-10-21 21:52:38', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (158, '2023-10-21 21:52:38', 55, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (159, '2023-10-21 21:54:12', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (160, '2023-10-21 21:54:12', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (161, '2023-10-21 21:54:12', 55, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (162, '2023-10-21 21:56:02', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (163, '2023-10-21 21:56:02', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (164, '2023-10-21 21:56:02', 55, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (165, '2023-10-21 21:56:22', 54, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (166, '2023-10-21 21:56:22', 54, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (167, '2023-10-21 21:56:22', 54, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (168, '2023-10-21 21:56:33', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (169, '2023-10-21 21:56:33', 56, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (170, '2023-10-21 21:56:33', 56, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (171, '2023-10-21 21:56:44', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (172, '2023-10-21 21:56:44', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (173, '2023-10-21 21:56:44', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (174, '2023-10-21 21:56:50', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (175, '2023-10-21 21:56:50', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (176, '2023-10-21 21:56:50', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (177, '2023-10-21 21:58:06', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (178, '2023-10-21 21:58:06', 56, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (179, '2023-10-21 21:58:53', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (180, '2023-10-21 21:58:53', 56, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (181, '2023-10-21 21:59:50', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (182, '2023-10-21 21:59:50', 56, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (183, '2023-10-21 21:59:50', 56, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (184, '2023-10-21 22:00:24', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (185, '2023-10-21 22:00:24', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (186, '2023-10-21 22:00:24', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (187, '2023-10-21 22:02:55', 56, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (188, '2023-10-21 22:03:53', 53, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (189, '2023-10-21 22:05:51', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (190, '2023-10-21 22:05:51', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (191, '2023-10-21 22:05:51', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (192, '2023-10-21 22:08:02', 53, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (193, '2023-10-21 22:08:02', 53, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (194, '2023-10-21 22:08:02', 53, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (195, '2023-10-21 22:09:11', 53, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (196, '2023-10-21 22:09:11', 53, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (197, '2023-10-21 22:09:11', 53, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (198, '2023-10-21 22:09:18', 53, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (199, '2023-10-21 22:09:18', 53, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (200, '2023-10-21 22:09:18', 53, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (201, '2023-10-21 22:11:17', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (202, '2023-10-21 22:11:17', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (203, '2023-10-21 22:11:17', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (204, '2023-10-21 22:11:25', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (205, '2023-10-21 22:11:25', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (206, '2023-10-21 22:11:25', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (207, '2023-10-21 22:12:23', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (208, '2023-10-21 22:12:23', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (209, '2023-10-21 22:12:23', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (210, '2023-10-21 22:12:32', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (211, '2023-10-21 22:12:32', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (212, '2023-10-21 22:12:32', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (213, '2023-10-21 22:16:58', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (214, '2023-10-21 22:16:58', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (215, '2023-10-21 22:16:58', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (216, '2023-10-21 22:17:02', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (217, '2023-10-21 22:17:02', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (218, '2023-10-21 22:17:02', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (219, '2023-10-21 22:17:06', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (220, '2023-10-21 22:17:06', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (221, '2023-10-21 22:17:06', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (222, '2023-10-21 22:17:32', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (223, '2023-10-21 22:17:32', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (224, '2023-10-21 22:17:32', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (225, '2023-10-21 22:17:34', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (226, '2023-10-21 22:17:34', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (227, '2023-10-21 22:17:34', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (228, '2023-10-21 22:18:13', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (229, '2023-10-21 22:18:13', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (230, '2023-10-21 22:18:13', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (231, '2023-10-21 22:18:18', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (232, '2023-10-21 22:18:18', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (233, '2023-10-21 22:18:18', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (234, '2023-10-21 22:18:20', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (235, '2023-10-21 22:18:20', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (236, '2023-10-21 22:18:20', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (237, '2023-10-21 22:18:24', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (238, '2023-10-21 22:18:24', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (239, '2023-10-21 22:18:24', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (240, '2023-10-21 22:18:29', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (241, '2023-10-21 22:18:29', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (242, '2023-10-21 22:18:29', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (243, '2023-10-21 22:18:31', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (244, '2023-10-21 22:18:31', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (245, '2023-10-21 22:18:31', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (246, '2023-10-21 22:18:34', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (247, '2023-10-21 22:18:34', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (248, '2023-10-21 22:18:34', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (249, '2023-10-21 22:18:36', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (250, '2023-10-21 22:18:36', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (251, '2023-10-21 22:18:36', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (252, '2023-10-21 22:19:42', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (253, '2023-10-21 22:19:42', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (254, '2023-10-21 22:19:42', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (255, '2023-10-21 22:20:24', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (256, '2023-10-21 22:20:24', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (257, '2023-10-21 22:20:24', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (258, '2023-10-22 10:22:34', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (259, '2023-10-22 10:22:34', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (260, '2023-10-22 10:22:34', 57, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (261, '2023-10-22 10:23:44', 57, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (262, '2023-10-22 10:25:44', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (263, '2023-10-22 10:25:44', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (264, '2023-10-22 10:25:44', 58, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (265, '2023-10-22 10:27:01', 58, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (266, '2023-10-22 10:46:19', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (267, '2023-10-22 19:17:19', 53, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (268, '2023-10-22 19:17:19', 53, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (269, '2023-10-22 19:17:19', 53, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (270, '2023-10-22 19:17:25', 57, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (271, '2023-10-22 19:17:25', 57, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (272, '2023-10-22 19:17:25', 57, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (273, '2023-10-22 19:20:10', 54, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (274, '2023-10-22 19:20:14', 56, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (275, '2023-10-22 19:20:22', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (276, '2023-10-22 19:28:47', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (277, '2023-10-22 19:28:47', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (278, '2023-10-22 19:28:47', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (279, '2023-10-22 19:38:36', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (280, '2023-10-22 19:38:36', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (281, '2023-10-22 19:38:36', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (282, '2023-10-22 19:39:02', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (283, '2023-10-22 19:39:02', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (284, '2023-10-22 19:39:02', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (285, '2023-10-22 19:40:27', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (286, '2023-10-22 19:40:27', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (287, '2023-10-22 19:40:27', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (288, '2023-10-22 19:41:04', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (289, '2023-10-22 19:41:04', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (290, '2023-10-22 19:41:04', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (291, '2023-10-22 19:41:11', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (292, '2023-10-22 19:41:15', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (293, '2023-10-22 19:41:15', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (294, '2023-10-22 19:41:15', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (295, '2023-10-22 19:42:34', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (296, '2023-10-22 19:42:34', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (297, '2023-10-22 19:42:34', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (298, '2023-10-22 19:42:40', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (299, '2023-10-22 19:42:45', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (300, '2023-10-22 19:42:45', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (301, '2023-10-22 19:42:45', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (302, '2023-10-22 19:43:08', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (303, '2023-10-22 19:43:14', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (304, '2023-10-22 19:43:14', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (305, '2023-10-22 19:43:14', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (306, '2023-10-22 19:43:24', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (307, '2023-10-22 19:43:48', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (308, '2023-10-22 19:43:48', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (309, '2023-10-22 19:43:48', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (310, '2023-10-22 19:44:01', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (311, '2023-10-22 19:44:29', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (312, '2023-10-22 19:44:29', 51, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (313, '2023-10-22 19:44:29', 51, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (314, '2023-10-23 09:52:38', 52, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (315, '2023-10-23 09:52:38', 52, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (316, '2023-10-23 09:52:38', 52, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (317, '2023-10-23 10:32:41', 51, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (318, '2023-10-23 11:00:36', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (319, '2023-10-23 11:00:36', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (320, '2023-10-23 11:00:36', 59, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (321, '2023-10-23 11:03:05', 59, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (322, '2023-10-23 11:03:21', 59, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (323, '2023-10-23 11:14:19', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (324, '2023-10-23 11:14:19', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (325, '2023-10-23 11:14:19', 60, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (326, '2023-10-23 11:16:19', 60, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (327, '2023-10-23 11:16:30', 60, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (328, '2023-10-24 13:55:54', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (329, '2023-10-24 13:58:18', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (330, '2023-10-24 13:58:18', 61, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (331, '2023-10-25 09:23:38', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (332, '2023-10-25 09:23:42', 8, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (333, '2023-10-25 09:23:49', 6, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (334, '2023-10-25 09:23:56', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (335, '2023-10-25 09:33:44', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (336, '2023-10-25 09:34:00', 8, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (337, '2023-10-25 09:34:10', 6, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (338, '2023-10-25 09:34:24', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (339, '2023-10-25 09:34:38', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (340, '2023-10-25 09:34:44', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (341, '2023-10-25 09:34:47', 8, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (342, '2023-10-25 09:34:58', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (343, '2023-10-25 09:35:09', 57, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (344, '2023-10-25 09:35:17', 58, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (345, '2023-10-25 09:35:27', 59, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (346, '2023-10-25 09:35:44', 60, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (347, '2023-10-25 09:35:48', 61, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (348, '2023-10-25 10:36:24', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (349, '2023-10-25 10:36:27', 8, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (350, '2023-10-25 10:36:31', 6, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (351, '2023-10-25 10:36:34', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (352, '2023-10-25 10:36:37', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (353, '2023-10-25 10:36:59', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (354, '2023-10-25 10:37:41', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (355, '2023-10-25 10:38:24', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (356, '2023-10-25 10:40:08', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (357, '2023-10-25 10:40:45', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (358, '2023-10-25 10:41:41', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (359, '2023-10-25 10:42:01', 8, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (360, '2023-10-25 10:42:02', 6, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (361, '2023-10-25 10:42:02', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (362, '2023-10-25 10:42:03', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (363, '2023-10-25 10:42:03', 57, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (364, '2023-10-25 10:42:04', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (365, '2023-10-25 10:42:04', 58, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (366, '2023-10-25 10:42:04', 60, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (367, '2023-10-25 10:42:05', 61, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (368, '2023-10-25 10:42:06', 59, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (369, '2023-10-25 12:08:31', 8, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (370, '2023-10-25 12:08:31', 8, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (371, '2023-10-25 12:08:31', 8, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (372, '2023-10-25 12:45:34', 60, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (373, '2023-10-25 12:45:38', 61, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (374, '2023-10-25 12:45:50', 59, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (375, '2023-10-25 12:48:17', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (376, '2023-10-25 12:48:56', 60, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (377, '2023-10-25 12:51:19', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (378, '2023-10-26 09:39:02', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (379, '2023-10-26 09:39:02', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (380, '2023-10-26 09:39:02', 62, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (381, '2023-10-26 09:40:36', 62, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (382, '2023-10-26 09:41:06', 62, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (383, '2023-10-26 10:52:05', 6, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (384, '2023-10-26 10:52:05', 6, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (385, '2023-10-26 10:52:05', 6, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (386, '2023-10-26 10:52:15', 6, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (387, '2023-10-26 10:52:15', 6, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (388, '2023-10-26 10:52:15', 6, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (389, '2023-10-26 10:53:49', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (390, '2023-10-26 10:53:49', 63, 'Add New Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (391, '2023-10-26 10:56:22', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (392, '2023-10-26 10:56:23', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (393, '2023-10-26 10:56:24', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (394, '2023-10-26 10:56:29', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (395, '2023-10-26 10:57:32', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (396, '2023-10-26 10:58:15', 57, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (397, '2023-10-26 15:32:09', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (398, '2023-10-26 15:36:03', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (399, '2023-10-26 15:36:12', NULL, 'Add Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (400, '2023-10-26 23:35:16', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (401, '2023-10-26 23:35:36', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (402, '2023-11-04 09:40:52', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (403, '2023-11-10 13:36:14', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (404, '2023-11-10 13:36:16', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (405, '2023-11-10 13:36:16', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (406, '2023-11-10 13:36:16', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (407, '2023-11-10 13:36:17', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (408, '2023-11-10 13:36:20', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (409, '2023-11-10 13:36:28', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (410, '2023-11-10 13:36:43', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (411, '2023-11-10 13:37:07', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (412, '2023-11-10 13:37:14', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (413, '2023-11-10 13:37:24', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (414, '2023-11-10 13:39:51', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (415, '2023-11-10 13:40:01', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (416, '2023-11-10 13:40:01', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (417, '2023-11-10 13:40:01', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (418, '2023-11-10 13:40:57', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (419, '2023-11-10 13:40:57', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (420, '2023-11-10 13:40:57', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (421, '2023-11-10 13:41:22', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (422, '2023-11-10 13:41:31', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (423, '2023-11-10 13:41:45', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (424, '2023-11-10 13:42:16', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (425, '2023-11-10 13:42:41', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (426, '2023-11-10 13:42:49', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (427, '2023-11-10 13:43:17', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (428, '2023-11-10 13:43:36', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (429, '2023-11-10 13:43:36', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (430, '2023-11-10 13:43:36', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (431, '2023-11-10 13:43:45', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (432, '2023-11-10 13:43:55', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (433, '2023-11-10 13:48:01', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (434, '2023-11-10 13:48:01', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (435, '2023-11-10 13:48:01', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (436, '2023-11-10 13:48:11', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (437, '2023-11-10 13:48:13', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (438, '2023-11-10 13:48:42', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (439, '2023-11-10 13:48:42', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (440, '2023-11-10 13:48:42', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (441, '2023-11-10 13:49:13', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (442, '2023-11-10 13:49:13', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (443, '2023-11-10 13:49:13', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (444, '2023-11-10 13:49:22', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (445, '2023-11-10 13:50:58', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (446, '2023-11-10 13:51:16', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (447, '2023-11-10 13:51:22', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (448, '2023-11-10 13:51:28', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (449, '2023-11-10 13:51:33', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (450, '2023-11-10 13:52:20', 63, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (451, '2023-11-10 14:05:01', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (452, '2023-11-10 14:05:01', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (453, '2023-11-10 14:05:01', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (454, '2023-11-10 14:05:10', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (455, '2023-11-10 14:05:10', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (456, '2023-11-10 14:05:10', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (457, '2023-11-13 10:19:08', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (458, '2023-11-13 10:19:08', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (459, '2023-11-13 10:19:10', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (460, '2023-11-13 10:19:11', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (461, '2023-11-13 10:19:11', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (462, '2023-11-13 10:19:12', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (463, '2023-11-13 10:19:13', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (464, '2023-11-13 10:19:13', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (465, '2023-11-13 10:19:14', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (466, '2023-11-13 10:19:15', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (467, '2023-11-13 10:19:15', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (468, '2023-11-13 10:19:16', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (469, '2023-11-13 10:48:11', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (470, '2023-11-13 10:48:11', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (471, '2023-11-13 10:48:11', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (472, '2023-11-13 10:48:14', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (473, '2023-11-13 10:48:15', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (474, '2023-11-13 10:48:15', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (475, '2023-11-13 10:48:41', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (476, '2023-11-13 10:48:41', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (477, '2023-11-13 10:48:41', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (478, '2023-11-13 10:48:43', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (479, '2023-11-13 10:48:43', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (480, '2023-11-13 10:48:43', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (481, '2023-11-13 10:49:03', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (482, '2023-11-13 10:49:03', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (483, '2023-11-13 10:49:03', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (484, '2023-11-13 10:49:04', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (485, '2023-11-13 10:49:04', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (486, '2023-11-13 10:49:04', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (487, '2023-11-13 10:49:09', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (488, '2023-11-13 10:49:09', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (489, '2023-11-13 10:49:09', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (490, '2023-11-13 10:49:32', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (491, '2023-11-13 10:49:38', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (492, '2023-11-13 10:49:38', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (493, '2023-11-13 10:49:38', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (494, '2023-11-13 10:49:40', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (495, '2023-11-13 10:49:40', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (496, '2023-11-13 10:49:40', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (497, '2023-11-13 10:49:51', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (498, '2023-11-13 10:49:51', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (499, '2023-11-13 10:49:51', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (500, '2023-11-13 10:49:57', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (501, '2023-11-13 10:49:57', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (502, '2023-11-13 10:49:57', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (503, '2023-11-13 10:50:00', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (504, '2023-11-13 10:50:00', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (505, '2023-11-13 10:50:00', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (506, '2023-11-13 13:45:14', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (507, '2023-11-13 13:45:14', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (508, '2023-11-13 13:45:15', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (509, '2023-11-13 13:45:18', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (510, '2023-11-13 13:45:38', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (511, '2023-11-13 13:45:38', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (512, '2023-11-13 13:45:38', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (513, '2023-11-13 13:45:40', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (514, '2023-11-13 13:45:40', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (515, '2023-11-13 13:45:40', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (516, '2023-11-13 13:45:46', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (517, '2023-11-13 13:45:46', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (518, '2023-11-13 13:45:46', 55, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (519, '2023-11-13 13:45:52', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (520, '2023-11-13 13:45:52', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (521, '2023-11-13 13:45:52', 55, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (522, '2023-11-13 13:46:01', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (523, '2023-11-13 13:46:01', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (524, '2023-11-13 13:46:01', 55, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (525, '2023-11-13 13:46:13', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (526, '2023-11-13 13:48:54', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (527, '2023-11-13 13:48:54', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (528, '2023-11-13 13:48:54', 55, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (529, '2023-11-13 13:49:02', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (530, '2023-11-13 13:49:02', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (531, '2023-11-13 13:49:02', 55, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (532, '2023-11-14 13:42:41', 59, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (533, '2023-11-14 13:42:41', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (534, '2023-11-14 13:42:41', 59, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (535, '2023-11-14 13:44:58', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (536, '2023-11-14 13:45:04', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (537, '2023-11-14 13:45:58', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (538, '2023-11-14 13:45:58', 8, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (539, '2023-11-14 13:45:58', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (540, '2023-11-14 13:53:49', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (541, '2023-11-14 13:53:49', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (542, '2023-11-14 13:53:49', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (543, '2023-11-14 13:53:57', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (544, '2023-11-14 14:10:31', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (545, '2023-11-14 14:10:31', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (546, '2023-11-14 14:10:31', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (547, '2023-11-14 14:21:59', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (548, '2023-11-14 14:22:38', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (549, '2023-11-14 14:22:38', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (550, '2023-11-14 14:22:38', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (551, '2023-11-14 14:22:45', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (552, '2023-11-14 14:22:45', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (553, '2023-11-14 14:22:45', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (554, '2023-11-14 14:24:31', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (555, '2023-11-14 14:25:24', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (556, '2023-11-14 14:30:58', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (557, '2023-11-14 14:31:00', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (558, '2023-11-14 14:31:00', NULL, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (559, '2023-11-14 14:32:05', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (560, '2023-11-14 14:32:05', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (561, '2023-11-14 14:32:05', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (562, '2023-11-14 14:32:58', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (563, '2023-11-14 14:32:58', 8, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (564, '2023-11-14 14:32:58', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (565, '2023-11-14 14:33:20', 8, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (566, '2023-11-14 14:33:20', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (567, '2023-11-14 14:33:20', 8, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (568, '2023-11-14 14:33:26', 8, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (569, '2023-11-14 14:33:26', 8, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (570, '2023-11-14 14:33:26', 8, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (571, '2023-11-14 14:35:15', 6, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (572, '2023-11-14 14:35:15', 8, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (573, '2023-11-14 14:35:15', 6, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (574, '2023-11-14 14:35:23', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (575, '2023-11-14 14:35:23', 55, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (576, '2023-11-14 14:35:23', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (577, '2023-11-14 14:35:36', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (578, '2023-11-14 14:35:36', 8, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (579, '2023-11-14 14:35:36', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (580, '2023-11-14 14:35:47', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (581, '2023-11-14 14:35:47', 8, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (582, '2023-11-14 14:35:47', 10, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (583, '2023-11-14 14:35:58', 55, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (584, '2023-11-14 14:35:58', 8, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (585, '2023-11-14 14:35:58', 55, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (586, '2023-11-14 14:36:08', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (587, '2023-11-14 14:36:08', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (588, '2023-11-14 14:36:08', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (589, '2023-11-14 14:36:16', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (590, '2023-11-14 14:37:18', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (591, '2023-11-14 14:37:18', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (592, '2023-11-14 14:37:18', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (593, '2023-11-14 14:37:27', 8, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (594, '2023-11-14 14:37:27', 7, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (595, '2023-11-14 14:37:27', 8, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (596, '2023-11-14 14:37:38', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (597, '2023-11-14 14:37:38', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (598, '2023-11-14 14:37:38', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (599, '2023-11-14 14:38:01', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (600, '2023-11-14 14:38:17', 6, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (601, '2023-11-14 14:38:33', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (602, '2023-11-14 14:38:33', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (603, '2023-11-14 14:38:33', 10, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (604, '2023-11-14 14:38:44', 56, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (605, '2023-11-14 14:38:44', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (606, '2023-11-14 14:38:44', 56, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (607, '2023-11-14 14:39:30', 10, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (608, '2023-11-14 14:44:56', 7, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (609, '2023-11-14 14:44:56', NULL, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (610, '2023-11-14 14:44:56', 7, 'Add Business Owner');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (611, '2023-11-14 14:45:24', 8, 'Edit Business');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (612, '2023-11-14 14:45:24', 8, 'Edit Business Address');
INSERT INTO `business_logs` (`id`, `date`, `bid`, `action`) VALUES (613, '2023-11-14 14:45:24', 8, 'Add Business Owner');


#
# TABLE STRUCTURE FOR: business_owner
#

DROP TABLE IF EXISTS `business_owner`;

CREATE TABLE `business_owner` (
  `owner_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `middle_name` varchar(60) DEFAULT NULL,
  `house_no` int(11) DEFAULT NULL,
  `building_name` varchar(60) DEFAULT NULL,
  `unit_no` int(11) DEFAULT NULL,
  `street` varchar(60) DEFAULT NULL,
  `barangay` varchar(60) DEFAULT NULL,
  `subdivision` varchar(60) DEFAULT NULL,
  `city` varchar(60) DEFAULT NULL,
  `province` varchar(60) DEFAULT NULL,
  `tel_no` bigint(20) DEFAULT NULL,
  `email_address` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (33, 'g', 'paul', 'morale', 0, 'Commercial Bldg', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (34, '', '', '', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (35, 'Paul', 'Morales', '', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (36, 'Sean', 'Asuncion', 'Valdez', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (37, 'June', 'Marcos', 'Bugnoy', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (38, 'Tim', 'Gread', 'Burne', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (39, 'Zeta', 'Minerva', 'Tan', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (40, 'Ong', 'Geyben', '', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (41, 'Sherwyn', 'Garces', 'Miranda', 0, '', 36, 'Cabarroguis', 'Salvacion', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (42, 'First', 'Last', 'Middle', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (43, 'kyle', 'lejao', 'g', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (44, 'james', 'rodrigo', 'amorin', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (45, '', '', '', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (46, 'Rodrigo Jr', 'Amorin ', 'S.', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '92827272', 'lunatic@gmail.com');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (47, 'Rdgie', 'Amorin', 'Suma', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (48, 'Something', 'Something', 'Something', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (49, 'Something', 'Something', 'Something', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (50, 'Sean', 'Asuncion', 'Valdez', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (51, 'Sean', 'Asuncion', 'Valdez', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `business_owner` (`owner_id`, `first_name`, `last_name`, `middle_name`, `house_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (52, 'Sean', 'Asuncion', 'Valdez', 0, '', 0, '', '', '', 'Bayombong', 'Nueva Vizcaya', '0', '');


#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `categories` (`id`, `name`, `description`) VALUES (1, 'Manufacturer', NULL);
INSERT INTO `categories` (`id`, `name`, `description`) VALUES (2, 'Retailer', NULL);
INSERT INTO `categories` (`id`, `name`, `description`) VALUES (3, 'Contractor', NULL);
INSERT INTO `categories` (`id`, `name`, `description`) VALUES (4, 'Services', NULL);
INSERT INTO `categories` (`id`, `name`, `description`) VALUES (5, 'Real Estate', NULL);
INSERT INTO `categories` (`id`, `name`, `description`) VALUES (6, 'Lessor Financial', NULL);
INSERT INTO `categories` (`id`, `name`, `description`) VALUES (7, 'Amusement', NULL);
INSERT INTO `categories` (`id`, `name`, `description`) VALUES (8, 'Learning Institute', NULL);
INSERT INTO `categories` (`id`, `name`, `description`) VALUES (9, 'Wholesaler', NULL);


#
# TABLE STRUCTURE FOR: location
#

DROP TABLE IF EXISTS `location`;

CREATE TABLE `location` (
  `pin` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `owner` varchar(45) DEFAULT NULL,
  `x` double DEFAULT '0',
  `y` double DEFAULT '0',
  `imgpath` varchar(100) DEFAULT NULL,
  `address` longtext,
  PRIMARY KEY (`pin`)
) ENGINE=MyISAM AUTO_INCREMENT=257 DEFAULT CHARSET=latin1;

INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (134, 'KKOPI', 'Paul Morales', '121.15576142302872', '16.48528095693989', 'http://localhost/BizLookUp/photos/KKOPI', '#133 Ponce Street st., Brgy. Don Mariano Marcos, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (135, 'BREAD N BITES', 'Alyssa Marie', '121.14880483863814', '16.48298137642074', 'http://localhost/BizLookUp/photos/BREADNBITES', '#0 Burgos Street st., Brgy. Barangay Don Mariano Perez, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (136, 'JMA BOARDING HOUSE & SARI-SARI STORE', 'Alma N Jacalne', '121.15452262359577', '16.481547308775276', 'http://localhost/BizLookUp/photos/JMABOARDINGHOUSE&SARI-SARISTORE', '#23 Cabarroguis st., Brgy. Salvacion, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (137, 'MZ Laundry Shop', 'Mary jane corpuz', '121.15381577500254', '16.48380069655363', 'http://localhost/BizLookUp/photos/MZLaundryShop', '#0 Regidor Street st., Brgy. Don Mariano Marcos, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (138, 'BLVD Express Convenient Store', 'Anne Lozano', '121.14961554337674', '16.481722168652595', 'http://localhost/BizLookUp/photos/BLVDExpressConvenientStore', '#0 Dumlao Boulevard st., Boulevard Subd., Brgy. Salvacion, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (140, 'Shawarma Bar', 'Geyben Ong', '121.15385180557287', '16.48392207386091', 'http://localhost/BizLookUp/photos/ShawarmaBar', '#348 Regidor Street st., Purok 3 Subd., Brgy. Don Mariano Marcos, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (141, 'Dhennies Kitchen', 'Dave Delos Santos', '121.1486302303244', '16.480014145646592', 'http://localhost/BizLookUp/photos/DhenniesKitchen', '#324 Dumlao Boulevard st., purok 1 Subd., Brgy. Salvacion, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (142, 'Barut Pet Shop', 'Nelson Barut', '121.15676902171468', '16.486729994709705', 'http://localhost/BizLookUp/photos/BarutPetShop', '#698 Sanjose Street st., purok 2Subd., Brgy. National, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (143, 'Pawfee Bean', 'John Kenneth Quintos', '121.1467910960495', '16.48098252080993', 'http://localhost/BizLookUp/photos/PawfeeBean', '#13 Zamora Street st., Purok 6Subd., Brgy. Don Domingo Maddela, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (146, 'Meogo Sarang Korean Mart', 'park so jouhe', '121.14894655300218', '16.480581478537147', 'http://localhost/BizLookUp/photos/MeogoSarangKoreanMart', '#438 Dumlao Boulevard st., purok 1Subd., Brgy. Don Mariano Perez, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (147, 'Someplace', '', '121.1503321028492', '16.484741162795345', 'http://localhost/BizLookUp/photos/Someplace', '#0 Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (148, '', '', '121.15208536169087', '16.479656620384958', 'http://localhost/BizLookUp/photos/', '#36 Cabarroguis st., Brgy. Salvacion, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (149, '', '', '0', '0', 'http://localhost/BizLookUp/photos/', '#23 Zulueta st., Brgy. Salvacion, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (150, 'saranay', '', '121.1486053831286', '16.48264867883654', 'http://localhost/BizLookUp/photos/saranay', '#23 saranay st., Brgy. batal, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (152, 'lejao Bldg', '', '121.14829739624008', '16.483800454025697', 'http://localhost/BizLookUp/photos/lejaoBldg', '#112 Borgos street st., Brgy. Salvacion, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (153, 'test', 'abc', '121.14642782023851', '16.47822589807592', 'http://localhost/BizLookUp/photos/test', '#0 Boulevard st., Brgy. Salvacion, Bayombong, Nueva Vizcaya');
INSERT INTO `location` (`pin`, `name`, `owner`, `x`, `y`, `imgpath`, `address`) VALUES (154, 'Felisas Coffe Shop', 'Rodrigo Jr, S. Amorin', '121.15798263917935', '16.487866893047382', 'http://localhost/BizLookUp/photos/FelisasCoffeShop', '#0 Brgy. District IV, Bayombong, Nueva Vizcaya');


#
# TABLE STRUCTURE FOR: location_logs
#

DROP TABLE IF EXISTS `location_logs`;

CREATE TABLE `location_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `lid` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;

INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (45, '2023-10-21 00:17:07', 134, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (46, '2023-10-21 00:23:10', 135, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (47, '2023-10-21 00:28:01', 136, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (48, '2023-10-21 00:32:35', 137, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (49, '2023-10-21 00:37:21', 138, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (50, '2023-10-21 00:42:51', 139, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (51, '2023-10-21 00:48:40', 140, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (52, '2023-10-21 00:52:33', 141, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (53, '2023-10-21 00:58:30', 142, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (54, '2023-10-21 01:05:07', 143, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (55, '2023-10-21 01:09:32', 144, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (56, '2023-10-21 01:14:27', 145, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (57, '2023-10-21 01:17:30', 146, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (58, '2023-10-21 01:21:15', 147, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (59, '2023-10-21 21:42:35', 140, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (60, '2023-10-21 21:43:45', 134, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (61, '2023-10-21 21:43:51', 135, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (62, '2023-10-21 21:43:55', 136, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (63, '2023-10-21 21:43:59', 137, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (64, '2023-10-21 21:44:03', 138, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (65, '2023-10-21 21:44:09', 141, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (66, '2023-10-21 21:44:13', 142, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (67, '2023-10-21 21:44:17', 143, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (68, '2023-10-21 21:44:21', 146, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (69, '2023-10-21 21:44:29', 147, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (70, '2023-10-21 22:02:55', 140, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (71, '2023-10-21 22:03:53', 136, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (72, '2023-10-22 10:22:34', 148, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (73, '2023-10-22 10:23:44', 148, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (74, '2023-10-22 10:25:44', 149, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (75, '2023-10-22 10:27:01', 149, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (76, '2023-10-22 19:20:10', 138, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (77, '2023-10-22 19:20:14', 140, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (78, '2023-10-22 19:20:22', 141, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (79, '2023-10-23 11:00:36', 150, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (80, '2023-10-23 11:03:05', 150, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (81, '2023-10-23 11:03:20', 150, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (82, '2023-10-23 11:14:19', 152, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (83, '2023-10-23 11:16:19', 152, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (84, '2023-10-24 13:55:54', 153, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (85, '2023-10-25 12:48:17', 141, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (86, '2023-10-25 12:48:56', 152, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (87, '2023-10-26 09:39:02', 154, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (88, '2023-10-26 09:40:36', 154, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (89, '2023-10-26 10:57:32', 153, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (90, '2023-10-26 10:58:15', 148, 'Edit Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (91, '2023-10-26 15:32:09', 155, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (92, '2023-10-26 15:36:03', 255, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (93, '2023-10-26 15:36:12', 256, 'Add Location');
INSERT INTO `location_logs` (`id`, `date`, `lid`, `action`) VALUES (94, '2023-11-04 09:40:52', 147, 'Edit Location');


#
# TABLE STRUCTURE FOR: region
#

DROP TABLE IF EXISTS `region`;

CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `coordinate` longtext,
  `type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `region` (`id`, `name`, `coordinate`, `type`) VALUES (8, 'Salvacion', '[[121.15022785600284,16.482837464667654],[121.15035013444967,16.48282781983839],[121.15057353888861,16.482643555095592],[121.15068266078713,16.482573815544555],[121.15081190447408,16.482504817881775],[121.15125360176097,16.48222234899572],[121.15186813555592,16.481886132127926],[121.15210529564438,16.4817354442893],[121.15253825049021,16.4814578611589],[121.1530153282998,16.48118292124478],[121.15346412129671,16.48090471569435],[121.15369493425257,16.480610471965363],[121.15431685895979,16.479163108566766],[121.15490771653535,16.478275955130925],[121.15146611510343,16.474719659661986],[121.14915843312515,16.474133644919974],[121.14723373457637,16.47641684721893],[121.14688424308636,16.476607401721566],[121.1467387737761,16.476777176545227],[121.14626960993735,16.477287576495613],[121.1457530886679,16.47786561653433],[121.14564767614752,16.478027305843412],[121.14579897504618,16.478071663710466],[121.14652281148473,16.47845772788267],[121.14737859711583,16.478937891878658],[121.14821214038835,16.479429771570366],[121.14835760969865,16.479559121914463],[121.14863901803206,16.48003314810667],[121.14924118930932,16.481115450178407],[121.14974321260664,16.481957954845143]]', 'Barangay');
INSERT INTO `region` (`id`, `name`, `coordinate`, `type`) VALUES (7, 'Don Domingo Maddela', '[[121.14778681210798,16.484214496995264],[121.14550241951137,16.481699921238075],[121.14528394139208,16.481821533901112],[121.1438472074404,16.479682339451514],[121.1459635680433,16.478408881451827],[121.14608807710987,16.47829402318351],[121.14821671647842,16.479494502275003],[121.14828484389825,16.479607107925304],[121.1488666090657,16.48062602892469],[121.14977707054531,16.48226880450747],[121.15012945449303,16.48286335303237],[121.14949986317747,16.48321557371247],[121.14877160301879,16.483620945957853],[121.14832994839924,16.483886689507685]]', 'Barangay');


#
# TABLE STRUCTURE FOR: settings_logs
#

DROP TABLE IF EXISTS `settings_logs`;

CREATE TABLE `settings_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `sid` int(11) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: status
#

DROP TABLE IF EXISTS `status`;

CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` longtext,
  `isDefault` tinyint(1) DEFAULT '0',
  `isRetired` tinyint(1) DEFAULT '0',
  `isApprove` tinyint(1) DEFAULT '0',
  `isCondition` tinyint(1) DEFAULT '0',
  `conditions` varchar(45) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `status` (`id`, `name`, `description`, `isDefault`, `isRetired`, `isApprove`, `isCondition`, `conditions`, `color`) VALUES (2, 'Registered', NULL, 0, 0, 1, 0, '0000000000', '#50C878');
INSERT INTO `status` (`id`, `name`, `description`, `isDefault`, `isRetired`, `isApprove`, `isCondition`, `conditions`, `color`) VALUES (3, 'Waiting', 'Pending but requirements are completed', 0, 0, 0, 1, '1111111111', '#395FFF');
INSERT INTO `status` (`id`, `name`, `description`, `isDefault`, `isRetired`, `isApprove`, `isCondition`, `conditions`, `color`) VALUES (4, 'Pending', NULL, 1, 0, 0, 0, '0000000000', '#DBFE87');
INSERT INTO `status` (`id`, `name`, `description`, `isDefault`, `isRetired`, `isApprove`, `isCondition`, `conditions`, `color`) VALUES (5, 'Removed', NULL, 0, 1, 0, 0, '0000000000', '#FF6961');


#
# TABLE STRUCTURE FOR: theme
#

DROP TABLE IF EXISTS `theme`;

CREATE TABLE `theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `bgfirst` varchar(45) DEFAULT NULL,
  `bgsecond` varchar(45) DEFAULT NULL,
  `cfirst` varchar(45) DEFAULT NULL,
  `csecond` varchar(45) DEFAULT NULL,
  `bfirst` varchar(45) DEFAULT NULL,
  `beffect` varchar(45) DEFAULT NULL,
  `isSelected` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `theme` (`id`, `name`, `bgfirst`, `bgsecond`, `cfirst`, `csecond`, `bfirst`, `beffect`, `isSelected`) VALUES (1, 'Theme 1', '#363636', '#48494B', '#D9D9D9', '#FFFFFF', '#00FFFF', '#2F2F2F', 0);
INSERT INTO `theme` (`id`, `name`, `bgfirst`, `bgsecond`, `cfirst`, `csecond`, `bfirst`, `beffect`, `isSelected`) VALUES (2, 'Theme 2', '#ffffff', '#ededed', '#000000', '#000000', '#0056c7', '#8f8f8f', 1);


#
# TABLE STRUCTURE FOR: types
#

DROP TABLE IF EXISTS `types`;

CREATE TABLE `types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `types` (`id`, `name`, `description`) VALUES (1, 'Single', NULL);
INSERT INTO `types` (`id`, `name`, `description`) VALUES (2, 'Partnership', NULL);
INSERT INTO `types` (`id`, `name`, `description`) VALUES (3, 'Corporation', NULL);
INSERT INTO `types` (`id`, `name`, `description`) VALUES (4, 'Cooperative', NULL);


#
# TABLE STRUCTURE FOR: view_business_details
#

DROP TABLE IF EXISTS `view_business_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_business_details` AS (select `a`.`number` AS `number`,`a`.`bin` AS `bin`,`a`.`name` AS `name`,`a`.`owner` AS `owner`,`a`.`owner_id` AS `owner_id`,`a`.`address` AS `address`,`a`.`incentives` AS `incentives`,`a`.`type` AS `type`,`a`.`status` AS `status`,`a`.`category` AS `category`,`a`.`date` AS `date`,`a`.`barangay_clearance` AS `barangay_clearance`,`a`.`tax_clearance` AS `tax_clearance`,`a`.`dti_registration` AS `dti_registration`,`a`.`sanitary_clearance` AS `sanitary_clearance`,`a`.`fire_clearance` AS `fire_clearance`,`a`.`building_permit` AS `building_permit`,`a`.`zoning_clearance` AS `zoning_clearance`,`a`.`contract_lease` AS `contract_lease`,`a`.`pic_clearance` AS `pic_clearance`,`a`.`menro_cert` AS `menro_cert`,`a`.`building_id` AS `building_id`,`a`.`business_area` AS `business_area`,`d`.`address` AS `location_address`,`b`.`bldg_no` AS `bldg_no`,`b`.`building_name` AS `building_name`,`b`.`unit_no` AS `unit_no`,`b`.`street` AS `street`,`b`.`barangay` AS `barangay`,`b`.`subdivision` AS `subdivision`,`b`.`city` AS `city`,`b`.`province` AS `province`,`b`.`tel_no` AS `tel_no`,`b`.`email_address` AS `email_address` from (((`business` `a` join `business_address` `b` on((`a`.`address` = `b`.`building_id`))) join `business_owner` `c` on((`a`.`owner_id` = `c`.`owner_id`))) join `location` `d` on((`a`.`building_id` = `d`.`pin`))));

utf8_general_ci;

INSERT INTO `view_business_details` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `location_address`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (7, '142-1', 'BREAD N BITES', 'Asuncion, Sean Valdez', 36, 7, NULL, 'Single', 'Pending', 'Wholesaler', '2023-10-10', 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 142, NULL, '#698 Sanjose Street st., purok 2Subd., Brgy. National, Bayombong, Nueva Vizcaya', 2331, 'Breads N Bites', 0, 'Burgos Street', 'Don Mariano Perez', '', 'Bayombong', 'Nueva Vizcaya', '0', 'Marie98@gmail.com');
INSERT INTO `view_business_details` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `location_address`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (8, '136-2', 'JMA BOARDING HOUSE & SARI-SARI STORE', 'Marcos, June Bugnoy', 37, 8, NULL, 'Single', 'Pending', 'Manufacturer', '2023-10-05', 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 136, NULL, '#23 Cabarroguis st., Brgy. Salvacion, Bayombong, Nueva Vizcaya', 4335, 'JMA Building', 23, 'Cabarroguis', 'Salvacion', '', 'Bayombong', 'Nueva Vizcaya', '9356631100', 'almajan@gmail.com');
INSERT INTO `view_business_details` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `location_address`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (6, '134-2', 'KKOPI', 'Morales, Paul ', 35, 6, NULL, 'Single', 'Registered', 'Lessor Financial', '2023-10-20', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 134, NULL, '#133 Ponce Street st., Brgy. Don Mariano Marcos, Bayombong, Nueva Vizcaya', 0, 'Commercial Bldg', 133, 'Ponce Street', 'Don Mariano Marcos', '', 'Bayombong', 'Nueva Vizcaya', '0', 'kkopi@gmail.com');
INSERT INTO `view_business_details` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `location_address`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (55, '136-4', 'MZ Laundry Shop', 'Minerva, Zeta Tan', 39, 9, NULL, 'Cooperative', 'Removed', 'Services', '2023-10-20', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 136, NULL, '#23 Cabarroguis st., Brgy. Salvacion, Bayombong, Nueva Vizcaya', 0, 'RS AND JOY Building', 0, 'Regidor Street', 'Don Mariano Marcos', '', 'Bayombong', 'Nueva Vizcaya', '9116801221', 'MaryJane@gmail.com');
INSERT INTO `view_business_details` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `location_address`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (57, '148-57', 'MicroTrendTestProject', 'Garces, Sherwyn Miranda', 41, 20, NULL, 'Single', 'Pending', 'Manufacturer', '2023-10-22', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 148, NULL, '#36 Cabarroguis st., Brgy. Salvacion, Bayombong, Nueva Vizcaya', 0, '', 36, 'Cabarroguis', 'Salvacion', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `view_business_details` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `location_address`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (58, '149-58', 'UniteLibrary', 'Last, First Middle', 42, 21, NULL, 'Single', 'Pending', 'Manufacturer', '2023-10-22', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 149, NULL, '#23 Zulueta st., Brgy. Salvacion, Bayombong, Nueva Vizcaya', 0, '', 23, 'Zulueta', 'Salvacion', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `view_business_details` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `location_address`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (59, '150-59', 'RC', 'lejao, kyle g', 43, 22, NULL, 'Single', 'Pending', 'Retailer', '2023-10-23', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 150, NULL, '#23 saranay st., Brgy. batal, Bayombong, Nueva Vizcaya', 0, '', 23, 'Saranay', 'Batal', '', 'Bayombong', 'Nueva Vizcaya', '0', '');
INSERT INTO `view_business_details` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `location_address`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (60, '152-60', 'Computernisumawang', 'rodrigo, james amorin', 44, 23, NULL, 'Single', 'Registered', 'Manufacturer', '2023-10-23', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 152, NULL, '#112 Borgos street st., Brgy. Salvacion, Bayombong, Nueva Vizcaya', 0, 'lejao Bldg', 112, 'Borgos street', 'Salvacion', '', 'Bayombong', 'Nueva Vizcaya', '23324', 'giegie@gmail.com');
INSERT INTO `view_business_details` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `location_address`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (62, '154-62', 'Felisas', 'Amorin , Rodrigo Jr S.', 46, 25, NULL, 'Single', 'Registered', 'Services', '2023-10-26', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 154, NULL, '#0 Brgy. District IV, Bayombong, Nueva Vizcaya', 0, 'Felisas Coffe Shop', 0, '', 'District IV', '', 'Bayombong', 'Nueva Vizcaya', '98', '');
INSERT INTO `view_business_details` (`number`, `bin`, `name`, `owner`, `owner_id`, `address`, `incentives`, `type`, `status`, `category`, `date`, `barangay_clearance`, `tax_clearance`, `dti_registration`, `sanitary_clearance`, `fire_clearance`, `building_permit`, `zoning_clearance`, `contract_lease`, `pic_clearance`, `menro_cert`, `building_id`, `business_area`, `location_address`, `bldg_no`, `building_name`, `unit_no`, `street`, `barangay`, `subdivision`, `city`, `province`, `tel_no`, `email_address`) VALUES (63, '134-63', 'Drinker', 'Amorin, Rdgie Suma', 47, 6, NULL, 'Single', 'Pending', 'Manufacturer', '2023-10-26', 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 134, NULL, '#133 Ponce Street st., Brgy. Don Mariano Marcos, Bayombong, Nueva Vizcaya', 0, 'Commercial Bldg', 133, 'Ponce Street', 'Don Mariano Marcos', '', 'Bayombong', 'Nueva Vizcaya', '0', 'kkopi@gmail.com');


#
# TABLE STRUCTURE FOR: view_category_count
#

DROP TABLE IF EXISTS `view_category_count`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_category_count` AS (select `business`.`category` AS `category`,count(`business`.`category`) AS `count` from `business` group by `business`.`category`);

utf8_general_ci;

INSERT INTO `view_category_count` (`category`, `count`) VALUES ('Lessor Financial', '2');
INSERT INTO `view_category_count` (`category`, `count`) VALUES ('Manufacturer', '5');
INSERT INTO `view_category_count` (`category`, `count`) VALUES ('Real Estate', '1');
INSERT INTO `view_category_count` (`category`, `count`) VALUES ('Retailer', '1');
INSERT INTO `view_category_count` (`category`, `count`) VALUES ('Services', '2');
INSERT INTO `view_category_count` (`category`, `count`) VALUES ('Wholesaler', '1');


#
# TABLE STRUCTURE FOR: view_date_barangay_count
#

DROP TABLE IF EXISTS `view_date_barangay_count`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_date_barangay_count` AS (select `a`.`date` AS `date`,year(`a`.`date`) AS `year`,month(`a`.`date`) AS `month`,dayofmonth(`a`.`date`) AS `day`,count(`a`.`number`) AS `count`,`b`.`barangay` AS `barangay` from (`business` `a` join `business_address` `b` on((`b`.`pin` = `a`.`building_id`))) group by `b`.`barangay`,`a`.`date`);

utf8_general_ci;

INSERT INTO `view_date_barangay_count` (`date`, `year`, `month`, `day`, `count`, `barangay`) VALUES ('2023-10-23', 2023, 10, 23, '1', 'Batal');
INSERT INTO `view_date_barangay_count` (`date`, `year`, `month`, `day`, `count`, `barangay`) VALUES ('2023-10-26', 2023, 10, 26, '1', 'District IV');
INSERT INTO `view_date_barangay_count` (`date`, `year`, `month`, `day`, `count`, `barangay`) VALUES ('2023-10-20', 2023, 10, 20, '1', 'Don Mariano Marcos');
INSERT INTO `view_date_barangay_count` (`date`, `year`, `month`, `day`, `count`, `barangay`) VALUES ('2023-10-26', 2023, 10, 26, '1', 'Don Mariano Marcos');
INSERT INTO `view_date_barangay_count` (`date`, `year`, `month`, `day`, `count`, `barangay`) VALUES ('2023-10-10', 2023, 10, 10, '1', 'National');
INSERT INTO `view_date_barangay_count` (`date`, `year`, `month`, `day`, `count`, `barangay`) VALUES ('2023-10-05', 2023, 10, 5, '1', 'Salvacion');
INSERT INTO `view_date_barangay_count` (`date`, `year`, `month`, `day`, `count`, `barangay`) VALUES ('2023-10-20', 2023, 10, 20, '3', 'Salvacion');
INSERT INTO `view_date_barangay_count` (`date`, `year`, `month`, `day`, `count`, `barangay`) VALUES ('2023-10-22', 2023, 10, 22, '2', 'Salvacion');
INSERT INTO `view_date_barangay_count` (`date`, `year`, `month`, `day`, `count`, `barangay`) VALUES ('2023-10-23', 2023, 10, 23, '1', 'Salvacion');


#
# TABLE STRUCTURE FOR: view_location_count
#

DROP TABLE IF EXISTS `view_location_count`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_location_count` AS (select `a`.`name` AS `name`,`b`.`name` AS `business`,count(`a`.`name`) AS `count` from (`location` `a` left join `business` `b` on((`a`.`pin` = `b`.`building_id`))) group by `a`.`name`);

utf8_general_ci;

INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('', 'MicroTrendTestProject', '2');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('Barut Pet Shop', 'BREAD N BITES', '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('BLVD Express Convenient Store', NULL, '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('BREAD N BITES', NULL, '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('Dhennies Kitchen', NULL, '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('Felisas Coffe Shop', 'Felisas', '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('JMA BOARDING HOUSE & SARI-SARI STORE', 'JMA BOARDING HOUSE & SARI-SARI STORE', '2');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('KKOPI', 'KKOPI', '2');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('lejao Bldg', 'Computernisumawang', '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('Meogo Sarang Korean Mart', NULL, '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('MZ Laundry Shop', NULL, '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('Pawfee Bean', NULL, '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('saranay', 'RC', '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('Shawarma Bar', NULL, '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('Someplace', NULL, '1');
INSERT INTO `view_location_count` (`name`, `business`, `count`) VALUES ('test', NULL, '1');


#
# TABLE STRUCTURE FOR: view_pin_count
#

DROP TABLE IF EXISTS `view_pin_count`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_pin_count` AS (select `business`.`building_id` AS `building_id`,count(0) AS `COUNT` from `business` group by `business`.`building_id`);

utf8_general_ci;

INSERT INTO `view_pin_count` (`building_id`, `COUNT`) VALUES (134, '2');
INSERT INTO `view_pin_count` (`building_id`, `COUNT`) VALUES (136, '2');
INSERT INTO `view_pin_count` (`building_id`, `COUNT`) VALUES (139, '2');
INSERT INTO `view_pin_count` (`building_id`, `COUNT`) VALUES (142, '1');
INSERT INTO `view_pin_count` (`building_id`, `COUNT`) VALUES (148, '1');
INSERT INTO `view_pin_count` (`building_id`, `COUNT`) VALUES (149, '1');
INSERT INTO `view_pin_count` (`building_id`, `COUNT`) VALUES (150, '1');
INSERT INTO `view_pin_count` (`building_id`, `COUNT`) VALUES (152, '1');
INSERT INTO `view_pin_count` (`building_id`, `COUNT`) VALUES (154, '1');


#
# TABLE STRUCTURE FOR: view_status_count
#

DROP TABLE IF EXISTS `view_status_count`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_status_count` AS (select `a`.`name` AS `status`,count(`b`.`status`) AS `count`,`a`.`color` AS `color` from (`status` `a` left join `business` `b` on((`a`.`name` = `b`.`status`))) group by `a`.`name` order by `a`.`id`);

utf8_general_ci;

INSERT INTO `view_status_count` (`status`, `count`, `color`) VALUES ('Registered', '3', '#50C878');
INSERT INTO `view_status_count` (`status`, `count`, `color`) VALUES ('Waiting', '0', '#395FFF');
INSERT INTO `view_status_count` (`status`, `count`, `color`) VALUES ('Pending', '8', '#DBFE87');
INSERT INTO `view_status_count` (`status`, `count`, `color`) VALUES ('Removed', '1', '#FF6961');


#
# TABLE STRUCTURE FOR: view_year_count
#

DROP TABLE IF EXISTS `view_year_count`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_year_count` AS (select year(`business`.`date`) AS `year`,count(`business`.`date`) AS `count` from `business` group by year(`business`.`date`));

utf8_general_ci;

INSERT INTO `view_year_count` (`year`, `count`) VALUES (2023, '12');


